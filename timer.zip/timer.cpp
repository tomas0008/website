#include <iostream>
#include <chrono>
#include <thread>

using Clock = std::chrono::high_resolution_clock;
using TimePoint = std::chrono::steady_clock::time_point;


void printTime(const bool* shouldGo)
{
	TimePoint startTime = Clock::now();
	
	int lastSecs = 0, lastMillis = 0;
	for (; *shouldGo;)
	{
		TimePoint endTime = Clock::now();
		
		int millis = (endTime-startTime) / std::chrono::milliseconds(1) % 1000,
			secs = (endTime-startTime) /std::chrono::seconds(1);
			
		if (secs == lastSecs && millis == lastMillis)
			continue;
		
		
		std::cout << (endTime-startTime) / std::chrono::seconds(1) << '.';
		
		if (millis < 10)
			std::cout << "00";
		else if (millis < 100)
			std::cout << 0;
		
		std::cout << millis << '\n';
		
		lastMillis = millis;
		lastSecs = secs;
	}
}


int main()
{
	std::cout << "q to stop\n\n";
	for (;;)
	{
		std::cout << "Enter: ";
		if (tolower(getchar()) == 'q')
			break;
		
		bool* shouldGo = new bool(true);
		
		std::thread timer(printTime, shouldGo);
		
		if (tolower(getchar()) == 'q')
		{
			*shouldGo = false;
			timer.join();
			delete shouldGo;
			break;
		}
		*shouldGo = false;
		timer.join();
		
		delete shouldGo;
	}
}